import json, re
I = json.load(open('imgs_datauri.json'))
CSS = open('style_block.css').read()

# extra CSS for area headers + neutral center card (no "added" badge)
CSS += """
  .area{font-family:Georgia,serif;font-size:16px;color:#fff;background:var(--navy);border-radius:8px;padding:9px 16px;margin:34px 0 6px;font-weight:600;letter-spacing:.01em}
  .area .cnt{float:right;font-weight:400;color:#cdd7e6;font-size:13px}
  .areasub{color:var(--mute);font-size:13px;margin:0 2px 14px}
  .ctitle{font-family:Georgia,serif;font-size:21px;font-weight:600}
  .ccity{color:var(--mute);font-size:14px}
  .agent{border-top:1px solid var(--line);padding-top:11px;font-size:12.5px;color:#33404f;margin-top:2px}
  .agent span{color:var(--mute);text-transform:uppercase;letter-spacing:.05em;font-size:10.5px;margin-right:3px}
"""

NAVY="#163868"

TOURURL="https://www.google.com/maps/dir/Crestview%2C%20FL/4506%20Hwy%2020%20E%2C%20Niceville%2C%20FL%2032578/Palm%20Plaza%2C%201003%20E%20John%20Sims%20Pkwy%2C%20Niceville%2C%20FL%2032578/Blueberry%20Rd%2C%20Freeport%2C%20FL%2032439/4935%20W%20Highway%2098%2C%20Santa%20Rosa%20Beach%2C%20FL%2032459/Mack%20Bayou%20Loop%20Rd%2C%20Santa%20Rosa%20Beach%2C%20FL%2032459/215%20Grand%20Blvd%2C%20Miramar%20Beach%2C%20FL%2032550/11275%20US%20Highway%2098%20W%2C%20Miramar%20Beach%2C%20FL%2032550/4399%20Commons%20Dr%2C%20Destin%2C%20FL%2032541"

CSS += """
  .routebox{margin:14px 0 2px;display:flex;align-items:center;gap:14px;flex-wrap:wrap}
  .routebtn{display:inline-block;background:var(--gold);color:#fff;text-decoration:none;font-weight:600;padding:11px 20px;border-radius:8px;font-size:14.5px;box-shadow:0 2px 8px rgba(185,138,46,.3)}
  .routebtn:hover{background:#a67b26}
  .routemeta{font-size:13px;color:var(--mute)}
  @media print{ .routebtn{background:#fff;color:var(--navy);border:1.5px solid var(--navy);box-shadow:none} }
  .notebox{margin:15px 0 2px;page-break-inside:avoid}
  .notebox h4{font-size:11.5px;color:var(--navy);margin:0 0 9px;text-transform:uppercase;letter-spacing:.07em}
  .noteline{height:29px;border-bottom:1px solid #c4ccd8}
  .noteline:first-of-type{border-top:1px solid #edf0f4}
  .usernote{margin:0 0 11px;font-size:14px;color:#26313f;background:#fbf7ee;border-left:3px solid var(--gold);padding:10px 13px;border-radius:0 6px 6px 0}
  .hero.fw{width:100%;height:280px}
  .cmedia1{margin-bottom:14px}
  @media print{ .noteline{height:26px;border-bottom:1px solid #9aa6b6} .hero.fw{height:230px} }
"""

# ---------- helpers ----------
def notes_block(dellnote="", lines=2):
    n = f'<p class="usernote">{dellnote}</p>' if dellnote else ''
    return '<div class="notebox"><h4>Notes</h4>' + n + ('<div class="noteline"></div>'*lines) + '</div>'

def clean_facts(rows):
    """Opex figures -> TBD; drop the all-in estimate (base rent is the total)."""
    out=[]
    for k,v in rows:
        if k=="Est. all-in / mo":
            continue
        if k=="Operating exp." and "gross" not in v.lower():
            v="TBD"
        out.append((k,v))
    return out

def facts(rows):
    rows=clean_facts(rows)
    return "".join(f'<div class="f"><span class="fk">{k}</span><span class="fv">{v}</span></div>' for k,v in rows)

def media_block(p):
    if p.get('hero') and p.get('loc'):
        return (f'<div class="cmedia"><img class="hero" src="{p["hero"]}" alt="{p["addr"]}">'
                f'<img class="loc" src="{p["loc"]}" alt="Location of {p["addr"]}"></div>')
    if p.get('hero'):
        return f'<div class="cmedia1"><img class="hero fw" src="{p["hero"]}" alt="{p.get("addr",p.get("title",""))}"></div>'
    return ""

def std_card(p):
    """Uniform fact-grid card."""
    ctr = f'<div class="pctr">{p["ctr"]}</div>' if p.get('ctr') else ''
    about="".join(f"<li>{x}</li>" for x in p['about'])
    conf ="".join(f"<li>{x}</li>" for x in p['confirm'])
    return f'''
    <section class="card">
      <div class="cnum">{p['n']}</div>
      <div class="chead"><div>
        <h3 class="paddr">{p['addr']}</h3>{ctr}
        <div class="pcity">{p['city']}</div>
      </div></div>
      {media_block(p)}
      <p class="pcopy">{p['copy']}</p>
      <div class="factgrid">{facts(p['facts'])}</div>
      <div class="twocol">
        <div class="mini"><h4>About the building</h4><ul>{about}</ul></div>
        <div class="mini"><h4>Confirm before signing</h4><ul>{conf}</ul></div>
      </div>
      {notes_block(p.get('dellnote',''),3)}
      <div class="agent"><span>Listing agent</span> {p['agent']} &nbsp;·&nbsp; <span>Source</span> {p['src']}</div>
    </section>'''

def center_card(c):
    """Uniform card for a multi-suite center: same chrome as std_card, with a suite table."""
    rows=""
    for s in c['suites']:
        badge=""
        if s.get('ground') is True: badge="<div style='margin-top:4px'><span class='gb gb-yes'>Ground floor</span></div>"
        elif s.get('ground') is False: badge="<div style='margin-top:4px'><span class='gb gb-no'>Upstairs</span></div>"
        cls="gr-yes" if s.get('ground') is True else ("gr-no" if s.get('ground') is False else "")
        rows+=(f"<tr class='{cls}'><td class='tc-where'>{s['name']}{badge}</td>"
               f"<td>{s['sf']}</td><td>{s['floor']}</td><td>{s['rate']}</td><td>{s['base']}</td>"
               f"<td>{s['cond']}</td><td>{s['avail']}</td><td class='gfit'>{s['fit']}</td></tr>")
    return f'''
    <section class="card">
      <div class="cnum">{c['n']}</div>
      <div class="chead"><div>
        <h3 class="paddr">{c['title']}</h3>
        <div class="pcity">{c['city']}</div>
      </div></div>
      {media_block(c)}
      <p class="pcopy">{c['intro']}</p>
      <div class="tblwrap"><table class="gbt">
        <thead><tr><th>Suite / configuration</th><th>Size</th><th>Floor</th><th>Rate</th><th>Base / mo</th><th>Condition</th><th>Availability</th><th>Dental fit</th></tr></thead>
        <tbody>{rows}</tbody>
      </table></div>
      <div class="gbnote">{c['note']}</div>
      {notes_block(c.get('dellnote',''),3)}
      <div class="agent"><span>Listing agent</span> {c['agent']} &nbsp;·&nbsp; <span>Source</span> {c['src']}</div>
    </section>'''

# ---------- ORIGINAL 5 (taglines removed, phones dropped) ----------
p1=dict(n="01",addr="2820 US Highway 98 West, Suite 1",city="Santa Rosa Beach",hero=I['h1'],loc=I['m1'],
  copy="Unfinished space on the main highway, single storey throughout, and the square footage lands almost exactly on target with no demising work needed. At $23/SF the base rent is roughly half what Mack Bayou asks. Be clear about what it is: the county roll says 2019 steel frame, and roughly 7,500 SF of the building has never been finished out. Your suite is part of that, so every dollar of build-out becomes a negotiating point. It is classified retail, so confirming dental use is the first call.",
  facts=[("Available","3,220 SF"),("Contiguous","3,220 SF"),("Asking rate","$23.00–24.00 /SF/yr"),("Base rent / mo","$6,440"),("Operating exp.","$5.00 /SF"),("Est. all-in / mo","≈ $7,782 /mo"),("Structure","Triple Net (NNN)"),("Available from","Aug 2026"),("Term","5 years"),("Status","Existing"),("Property type","Retail"),("Building class","A"),("Year built","2019 (county) · listed 2026"),("Building size","20,144 SF"),("Storeys","1"),("Zoning","Commercial")],
  about=["US Highway 98 frontage","Single storey throughout, which suits an operatory layout","Operating expenses to be confirmed with the landlord","Close to two acres of land, so the site is not tight"],
  confirm=["Whether dental use is permitted under the retail zoning","Build-out allowance, which matters more here than anywhere else on the list","Electrical service and whether the shell is stubbed for plumbing","Parking count and the shared load across the center"],
  agent="Taylor Allen Properties · Chad Knaepple",src="CoStar, ECAR, Moody's CRE")

p2=dict(n="02",addr="142 John Galt Road, Suite A",city="Santa Rosa Beach",hero=I['h2'],loc=I['m2'],
  copy="Three thousand square feet at $22/SF in a building finished last year, listed under a month, available now rather than next year. That combination is rare. The honest reservation is what it looks like: a metal building with two roll-up doors in a commerce park, and a patient pulling into that lot would not assume they had arrived at a dental office. For a practice built on referrals that matters much less; for one built on drive-by visibility it matters a great deal. It is really a question about how she plans to bring patients in.",
  facts=[("Available","3,000 SF"),("Contiguous","3,000 SF"),("Asking rate","$22.00 /SF/yr"),("Base rent / mo","$5,500"),("Operating exp.","Not published"),("Est. all-in / mo","TBD"),("Structure","Triple Net (NNN)"),("Available from","Immediately"),("Term","Negotiable"),("Status","Existing"),("Property type","Industrial / flex"),("Building class","Not published"),("Year built","2025"),("Building size","6,000 SF"),("Storeys","Not published"),("Zoning","Not published")],
  about=["Completed 2025, available immediately","Dedicated surface parking directly in front of the unit"],
  confirm=["Whether the roll-up doors can be infilled and the facade given a professional frontage","Zoning for medical use in an industrial park","Electrical service","Signage rights on Highway 98 to offset the setback"],
  agent="Scenic Sotheby's International Realty · Wes Madden",src="CoStar, ECAR")

p3=dict(n="03",addr="Lot 5 Mack Bayou Loop Road",city="Santa Rosa Beach",ctr="Mack Bayou Center",hero=I['h3'],loc=I['m3'],
  copy="Classified for medical and office use and still under construction, which works in her favor: a building going up now can be finished to her operatory plan instead of paying to undo somebody else's walls. Since this list was first drawn, the 3,256 SF block is confirmed as first-floor new construction, which settles the ground-floor question. What remains is price and timing. At $45/SF this is the most expensive on the list by a wide margin, delivery is November, and the space is a full buildout. The listing broker and the building owner are the same party, so she would negotiate directly with the decision maker.",
  facts=[("Available","1,433–6,122 SF"),("Contiguous","3,256 SF"),("Asking rate","$45.00 /SF/yr"),("Base rent / mo","$12,210"),("Operating exp.","Not published"),("Est. all-in / mo","TBD"),("Structure","Triple Net (NNN)"),("Available from","Nov 2026"),("Term","5–10 years"),("Status","Under construction"),("Property type","Office / Medical"),("Building class","B"),("Year built","2026"),("Building size","8,954 SF"),("Storeys","3 (your block confirmed 1st floor)"),("Zoning","Not published")],
  about=["Newly constructed Class A three-storey executive and medical office","Your 3,256 SF block is confirmed first-floor new construction","Full buildout, so the interior is finished to your operatory plan","Welcoming lobby with an open modern stair and strong daylight"],
  confirm=["Parking count and whether it is dedicated or shared","Electrical service to the suite, 200 amp against 400 amp","Build-out allowance against the roughly $180/SF medical/office benchmark (dental often runs higher)","Whether operatory plumbing can still be roughed in at this stage"],
  agent="Berkshire Hathaway HS PenFed Realty · Matthew Fetter",src="CoStar")

p4=dict(n="04",addr="11275 Emerald Coast Parkway, Suite 6",city="Miramar Beach",ctr="Rufus Ray Plaza",hero=I['h4'],loc=I['m4'],
  copy="Her Miramar Beach option, and the least expensive space on this list. 2,600 SF on the ground floor of a single storey plaza on Emerald Coast Parkway, inside the target range with no demising work, built 2017 and available now. Monument signage at the road, surface parking in front of the unit, neighbors who bring people to the center all day. The national database lists the asking rate at $218.40/SF, a resort-retail number that reads as absurd for a clinic; the local MLS publishes the same suite at $18.27/SF. The first figure is the second multiplied by twelve, a units error rather than a price.",
  facts=[("Available","2,600 SF"),("Contiguous","2,600 SF"),("Asking rate","$18.27 /SF/yr"),("Base rent / mo","$3,958"),("Operating exp.","$4.19 /SF"),("Est. all-in / mo","≈ $4,866 /mo"),("Structure","Triple Net (NNN)"),("Available from","Immediately"),("Term","Negotiable"),("Status","Existing"),("Property type","Retail"),("Building class","B"),("Year built","2017"),("Building size","28,000 SF"),("Storeys","1"),("Zoning","Not published")],
  about=["Inside the target size range with no demising needed","Built 2017, existing and available now","Ground floor of a single storey plaza on the main corridor"],
  confirm=["The asking rate direct from the landlord, since two sources disagree by a factor of twelve","Whether dental use is permitted, as this is retail space","Parking count for the suite within a 28,000 SF center","Depth and shape of the suite, which decides whether six operatories fit"],
  agent="NBI Properties, Inc. · Craig Barrett",src="CoStar, ECAR, Moody's CRE")

p5=dict(n="05",addr="3214 US Highway 98",city="Santa Rosa Beach",hero=I['h5'],loc=I['m5'],
  copy="If the setting matters, this is the one. A new single storey professional village on the corridor: wide clean elevations, deep surface parking on both sides, a planted central drive, and neighbors who are title companies and mortgage offices rather than trade counters. A patient turning in here knows immediately they have arrived somewhere professional. It is also the priciest after Mack Bayou. 4,155 SF is about 750 above the ceiling, and at $35/SF the base rent is about twelve thousand a month. Ask whether the landlord will demise below 4,155 SF.",
  facts=[("Available","4,155 SF"),("Contiguous","4,155 SF"),("Asking rate","$34.66–35.04 /SF/yr"),("Base rent / mo","$12,000"),("Operating exp.","$7.50 /SF"),("Est. all-in / mo","≈ $14,597 /mo"),("Structure","TBD"),("Available from","Immediately"),("Term","5 years"),("Status","Existing"),("Property type","Retail"),("Building class","B"),("Year built","2025"),("Building size","11,246 SF"),("Storeys","1"),("Zoning","Commercial")],
  about=["Highway 98 frontage with strong visibility","New 2025 professional village, title and mortgage neighbors","Zoned Commercial on the MLS record"],
  confirm=["Whether the landlord will demise below 4,155 SF","Service type (NNN vs gross), which the national record leaves undetermined","Parking","Construction status confirmed on site, since two sources disagreed"],
  agent="Somers & Company · John Paul Somers",src="CoStar, ECAR, Moody's CRE")

# NEW: 4935 W Hwy 98 (merged from srb_jimball; resolves 4935 vs 4955)
p6=dict(n="06",addr="4935 West Highway 98",city="Santa Rosa Beach",
  copy="The address the old list flagged as 4935 vs 4955 is confirmed: 4935 W Hwy 98, a premier retail and flex complex now delivering on Highway 98. Class-A retail, showroom, warehouse and flex spaces with 24-foot ceilings, roll-up doors, and coastal finishes, roughly 3,700 to 5,200 SF, some with 730 SF second-floor office mezzanines. A single 3,600 SF flex unit lists at $28.50/SF, and the landlord is offering five months free rent on flex spaces, real leverage on a startup budget. Signed tenants already include a medical spa, a fitness concept, and a coffee shop, so the co-tenancy leans service and wellness.",
  facts=[("Available","3,600 SF"),("Contiguous","3,600 SF"),("Asking rate","$28.50 /SF/yr"),("Base rent / mo","$8,550"),("Operating exp.","$6.00 /SF (CAM)"),("Est. all-in / mo","≈ $10,350 /mo"),("Structure","Triple Net (NNN)"),("Available from","Mar 2026"),("Term","5 years"),("Status","Under construction"),("Property type","Neighborhood center / flex"),("Building class","A"),("Year built","2025"),("Building size","33,508 SF"),("Storeys","1 (+ 730 SF mezzanine option)"),("Zoning","Commercial")],
  about=["Five months free rent offered on flex spaces","24-foot ceilings, roll-up doors, coastal finishes","Signed tenants: medical spa, fitness, coffee shop","Highway 98 frontage, 2.4-acre site"],
  confirm=["Whether dental use fits the flex/retail zoning","Build-out allowance and delivered shell condition","Electrical service for a 3,000+ SF dental build","Parking count and CAM reconciliation"],
  agent="Century 21 All Points Realty · Jim Ball",src="ECAR / Emerald Coast MLS")

# NEW single card: Commons Dr Destin (2nd floor)
p7=dict(n="11",addr="4399 Commons Drive, Unit 200A",city="Destin",ctr="Runnels Professional Building · Kelly Plantation",
  copy="A move-in-ready professional suite in a three-storey building at Kelly Plantation, already home to orthodontists, financial advisors, attorneys, a title company, and an accountant, so the professional co-tenancy is strong. 2,200 SF with a reception area off the elevator foyer, six offices, a conference room with covered patio access, and a kitchen. The gross rent of $5,500 a month folds in base rent, triple net, water, sewer, trash, and electricity, which makes budgeting clean. The catch for a dental use is the floor: it is on the second storey, the same constraint that shaped the rest of this list.",
  facts=[("Available","2,200 SF"),("Contiguous","2,200 SF"),("Asking rate","≈ $30 /SF (gross)"),("Base rent / mo","$5,500 (gross)"),("Operating exp.","Included in gross"),("Est. all-in / mo","$5,500 /mo"),("Structure","Gross (NNN + utilities included)"),("Available from","Existing"),("Term","36–60 months"),("Status","Existing"),("Property type","Professional / Office"),("Building class","Not published"),("Year built","2006"),("Storeys","3 (suite on 2nd floor)"),("Zoning","Not published")],
  about=["Gross rent includes NNN, water, sewer, trash, and electricity","Professional co-tenancy: orthodontist, title, financial, legal","Six offices, conference room, kitchen, covered rear patio","Kelly Plantation location in East Destin"],
  confirm=["Second floor: whether operatory plumbing, vacuum lines, equipment access, and post-sedation egress can work","Whether dental use is permitted","Parking count for the building","Elevator access and equipment delivery path"],
  agent="Taylor Allen Properties",src="ECAR / Emerald Coast MLS")

# Compact worth-a-look (SRB / Miramar) - kept, phones dropped, no taglines
lc_palustris=dict(addr="Palustris Road, LIVO Commerce Park",city="Santa Rosa Beach",sf="906–8,555 SF (5,178 contig)",rate="Rate not published",mo="Under construction, delivers Sep 2026",
  note="Eight suites, so the demise can be fitted to requirement and the interior built to plan. No asking rate published, the one thing keeping it out of the front group. One call resolves it.",agent="CBRE · Tom Watson")
lc_12889=dict(addr="12889 Emerald Coast Parkway, Suite 110-A",city="Miramar Beach",sf="2,244 SF",rate="$15.24 /SF",mo="$2,850 /mo base",
  note="Inexpensive for Miramar. Sits just under target, so five operatories rather than six or seven. Could work if the layout is efficient or the neighboring suite comes open.",agent="Destin Beach Realty · Wanda Greer")
lc_12605=dict(addr="12605 US Highway 98, Unit 5",city="Miramar Beach",sf="Size not published",rate="Not published",mo="$2,506 /mo",
  note="Commercial suite in a 10,900 SF building, zoned Commercial. Suite size is not published, the one number that decides whether it belongs. If it runs near 2,400 SF the rate is very good.",agent="Compass")

# ---------- CENTERS ----------
grand=dict(title="Grand Boulevard Center",city="Miramar Beach / Sandestin",hero=I['gb_hero'],
  cap="Grand Boulevard at Sandestin, the open-air center. Photo: grandboulevard.com.",
  intro="The Grand Boulevard lifestyle center by the Sandestin gate, a mixed-use Town Center with strong daytime traffic and a professional address. Several suites are open across a range of visibility, timing, and buildout. For a dental fit the first filter is floor level: the ground-floor options are the real candidates, and the upstairs suites carry the same plumbing and egress caveat as the rest of this list.",
  suites=[
    dict(name="Baytowne Office, 215 Grand Blvd, Suite 102",sf="3,830 SF",floor="First floor",rate="$23.50 /SF",base="$7,500 /mo",avail="Available 2/1/27",cond="Buildout space",ground=True,
      fit="Ground floor and at the top of your band. Needs a full buildout and delivers February 2027. The strongest Grand Boulevard candidate for the use."),
    dict(name="195 Grand Blvd, Suite 102",sf="1,555 SF",floor="First floor retail",rate="$23.50 /SF",base="$3,045 /mo",avail="Available now",cond="Move-in ready · prior attorney office",ground=True,
      fit="Ground floor, move-in ready, prior office layout that may convert easily. At 1,555 SF it is below target, roughly four operatories."),
    dict(name="Town Center Retail, Suite 210",sf="3,219 SF",floor="Upstairs",rate="$27.25 /SF + $80/SF TIA",base="$7,310 /mo",avail="Available now",cond="Full buildout required",ground=False,
      fit="Large TI allowance, but upstairs, so the ground-floor caveat applies for a dental build."),
    dict(name="215 Grand Blvd, Suite 201",sf="2,631 SF",floor="Upper floor",rate="$23.50 /SF",base="$5,153 /mo",avail="Available now",cond="Move-in ready",ground=False,
      fit="Move-in ready and well priced, but upstairs."),
    dict(name="1655-755 Grand Blvd (Howard Group)",sf="1,000–6,370 SF",floor="2nd (per CoStar)",rate="Not disclosed",base="—",avail="Immediately",cond="Class-A office",ground=False,
      fit="A larger Class-A office block, up to 6,370 SF. CoStar shows the available block on the 2nd floor and the rate undisclosed; confirm the floor, since a first-floor 3,400 SF block was referenced separately."),
  ],
  note="A full medical/office buildout runs roughly $180/SF depending on finishes; a dental fit-out with operatory plumbing typically runs higher, a planning number for any full-buildout space here or at Mack Bayou, 3214 US-98, and Corporate Woods.",
  agent="The Howard Group · Dana Hahn (EVP Real Estate)",src="Stiles review · CoStar")

corporate=dict(title="Corporate Woods",city="Freeport · Hwy 20 corridor",
  intro="The one purpose-built medical option in this set. A Class-A medical and professional campus on Highway 20 in Freeport, five two-storey elevator-served buildings delivered as a cool white-box shell for interior finishes. It is built for the use: target users listed include specialty dental, and the parking runs about 4.5 spaces per 1,000 SF, stronger than almost anything on the coastal side and the constraint that usually kills a dental space. The trade-offs are size, geography, and timing. Individual suites are small at 568 and 747 SF, so a 2,400 to 3,400 SF footprint means combining units or taking a full floor. It sits inland in Freeport, which trades coastal proximity for a lower cost basis, and Phase 1 (Buildings A and B) delivers late 2026 or early 2027. Offered for lease or for condominium purchase, which is a rare owner-user option for a startup that wants to build equity.",
  suites=[
    dict(name="Single suite (Bldgs B/D)",sf="568 SF",floor="1st or 2nd",rate="$35–45 /SF NNN",base="~$1,657–2,130 /mo",avail="Late 2026 / early 2027",cond="Cool white-box shell",ground=None,
      fit="Below target on its own; a building block to combine."),
    dict(name="Single suite (Bldgs A/C/E)",sf="747 SF",floor="1st or 2nd",rate="$35–45 /SF NNN",base="~$2,180–2,801 /mo",avail="Late 2026 / early 2027",cond="Cool white-box shell",ground=None,
      fit="Below target on its own; a building block to combine."),
    dict(name="Combined suites (to your band)",sf="≈ 2,240–3,000 SF",floor="Ground preferred",rate="$35–45 /SF NNN",base="≈ $6,500–11,250 /mo",avail="Late 2026 / early 2027",cond="Shell, built to plan",ground=None,
      fit="Combine three to four units on the ground floor to hit 2,400–3,400 SF, finished to an operatory plan."),
    dict(name="Whole building (A or B)",sf="4,482–4,544 SF",floor="2 storeys",rate="Lease $35–45 /SF · Buy $675–775 /SF",base="For-sale units from ≈ $395,000",avail="Late 2026 / early 2027",cond="Shell",ground=None,
      fit="Above the band, but a full-building owner-user or lease play; SBA-financing eligible for purchase."),
  ],
  note="Lease rates projected $35–45/SF NNN; TI allowance negotiable and a ~90-day buildout typical. For purchase, projected $675–775/SF, SBA-eligible. Best parking ratio in the whole set and the only campus pre-designed for medical, against a Freeport location and a 2027 delivery.",
  agent="Century 21 All Points Realty · Jim Ball",src="ECAR / Emerald Coast MLS · marketing package")

bluewater=dict(title="Bluewater Bay Shopping Center & Office Complex",city="Niceville · Hwy 20 E",
  intro="A Winn-Dixie-anchored grocery center in the heart of the Niceville trade area, about 105,599 SF with over 33,000 vehicles per day on Highway 20, ample parking, and prominent pylon signage. The draw for a startup is a grocery-anchored traffic base and a suite already fit out as medical space. Suites run 1,200 to 4,000 SF, so the medical and larger office units sit at or above the top of the target band.",
  suites=[
    dict(name="Suite 4536",sf="4,000 SF",floor="Ground",rate="$22.00 /SF",base="≈ $7,333 /mo",avail="Available",cond="Medical space",ground=True,
      fit="The only pre-designated medical suite here, ground floor. About 600 SF above target; ask whether it can be demised down."),
    dict(name="Suite 1507",sf="4,000 SF",floor="Ground",rate="$22.00 /SF",base="≈ $7,333 /mo",avail="Available",cond="Office space",ground=True,
      fit="Ground-floor office, above band; a conversion candidate if the medical suite is gone."),
    dict(name="Suite 4506-250",sf="1,918 SF",floor="Ground",rate="$15.00 /SF",base="≈ $2,398 /mo",avail="Available",cond="Office space",ground=True,
      fit="Below target, five operatories at most, but the lowest base rate in the center."),
    dict(name="Suite 4546",sf="1,200 SF",floor="Ground",rate="$28.00 /SF",base="≈ $2,800 /mo",avail="Available 2/1/27",cond="Endcap restaurant",ground=True,
      fit="Endcap, too small for the use; noted for completeness."),
  ],
  note="Grocery-anchored co-tenancy and 33,000 VPD are the real assets here. The medical suite (4536) is the one to price and to ask about demising toward the target band.",
  agent="Bellcore Commercial · Harry Bell Jr.",src="Crexi")

palm=dict(title="Palm Plaza",city="Niceville · E John Sims Pkwy",
  intro="A retail and office plaza on East John Sims Parkway in the heart of Niceville, with a daily traffic count around 40,000. Two ground-floor suites are open, and one lands squarely in the target band at one of the lowest base rents in the whole set.",
  suites=[
    dict(name="Suite 1039",sf="2,500 SF",floor="Ground",rate="$19.00 /SF",base="≈ $3,958 /mo",avail="Available 7/1/26",cond="Open retail",ground=True,
      fit="In the target band, ground floor, and one of the lowest base rents in the set. Open 25x100 retail shell with one restroom and rear storage, so a full operatory buildout is needed."),
    dict(name="Suite 1047",sf="5,000 SF",floor="Ground",rate="$17.00 /SF",base="≈ $7,083 /mo",avail="Available now",cond="Move-in ready office",ground=True,
      fit="Above the band, move-in ready with 12 offices and two ADA restrooms; a conversion or room-to-grow play."),
  ],
  note="The 2,500 SF retail suite carries one of the lowest base rents in the whole set at $19/SF. The building dates to 1974, so verify electrical service, roof, and HVAC before it moves up the list.",
  agent="Ruckel Properties, Inc.",src="Moody's CRE")

# ---------- numbering, Dell's notes, and added photos ----------
p1['n']="1"; p1['dellnote']="Industrial building, and will not work for a healthcare use. I do not recommend it."
p2['n']="2"; p2['dellnote']="Industrial building. I do not recommend it."
p3['n']="3"; p3['dellnote']="The rent rate pushes this option over the annual cap for the lending requirements."
p4['n']="4"; p4['dellnote']="Could be a really good option, and the rents work. We would need to move fast, it will not last in this market."
p5['n']="5"; p5['dellnote']="Too large, and the rent pushes over the cap for lending. The buildout cost would run over as well. I do not recommend it."
p6['n']="6"; p6['dellnote']="Could be a good option, since the parking is more than expected, as we discussed at coffee."; p6['hero']=I['p6_hero']
p7['n']="11"; p7['dellnote']="Multi-story building around the commons."; p7['hero']=I['commons_hero']

grand['n']="7"; grand['dellnote']="Great option at roughly 3,500 SF on the first floor, with signage, and the rents work."
corporate['n']="8"; corporate['dellnote']="Could be great. Units can be purchased or rented, with a potential purchase option during the lease."; corporate['hero']=I['corp_hero']
bluewater['n']="9"; bluewater['dellnote']="Might work. We should discuss further."; bluewater['hero']=I['blue_hero']
palm['n']="10"; palm['dellnote']="Older building, and not sure it is the right fit for you."; palm['hero']=I['palm_hero']

# ---------- comparison table ----------
def trow(cells, boldcol=5):
    def cls(i):
        if i==0: return ' class="tc-num"'
        if i==boldcol: return ' class="tc-all"'
        return ''
    tds="".join("<td%s>%s</td>" % (cls(i), c) for i,c in enumerate(cells))
    return "<tr>%s</tr>" % tds

# [#, Property, Area, Size, Asking/SF, Base/mo, Opex, Status]  (base monthly is the total; opex TBD)
table_rows = [
 ["1","2820 US Hwy 98 W, Ste 1","Santa Rosa Beach","3,220 SF","$23–24","$6,440","TBD","Existing shell"],
 ["2","142 John Galt Rd, Ste A","Santa Rosa Beach","3,000 SF","$22.00","$5,500","TBD","Existing"],
 ["3","Mack Bayou Center","Santa Rosa Beach","3,256 SF","$45.00","$12,210","TBD","U/C · 1st-floor block"],
 ["4","Rufus Ray Plaza (11275)","Miramar Beach","2,600 SF","$18.27","$3,958","TBD","Existing"],
 ["5","3214 US Hwy 98","Santa Rosa Beach","4,155 SF","$35.00","$12,000","TBD","Existing"],
 ["6","4935 W Hwy 98","Santa Rosa Beach","3,600 SF","$28.50","$8,550","TBD","U/C · 5 mo free"],
 ["7","Grand Boulevard (range)","Miramar / Sandestin","1,555–3,830 SF","$23.50–27.25","varies","TBD","Mixed floors"],
 ["8","Corporate Woods","Freeport","568–4,544 SF*","$35–45","varies","TBD","U/C · 2027"],
 ["9","Bluewater Bay, Ste 4536","Niceville","4,000 SF","$22.00","$7,333","TBD","Available · medical"],
 ["10","Palm Plaza, Ste 1039","Niceville","2,500 SF","$19.00","$3,958","TBD","Avail 7/1/26"],
 ["11","4399 Commons Dr, 200A","Destin","2,200 SF","≈$30 gross","$5,500","TBD","Existing · 2nd fl"],
]
thead="<tr><th>#</th><th>Property</th><th>Area</th><th>Size</th><th>Asking/SF</th><th>Base / mo</th><th>Opex/SF</th><th>Status</th></tr>"
tbody="".join(trow(r,boldcol=5) for r in table_rows)

# ---------- ruled out (kept, neutral heading) ----------
ruled=[
 ("Second floor","12598 US Hwy 98 Ste 200 (3,371 SF, finished, $23) and 42 Business Centre Dr Stes 203-206 (3,022 SF, the only existing medical/dental-classified building in the original search). Both upstairs. A dental practice belongs on the ground floor for plumbing, vacuum and compressor lines, equipment delivery, and post-sedation egress. Lines kept open in case a ground-floor unit opens in either building."),
 ("Wrong setting for a clinic","259 WRM Circle (warehouse), 605 N County Hwy 393 #13A & #16 (light industrial park), 334 Goldsby Rd (Class C commerce park), 9300 Baytowne Wharf (resort village), A7/A8 Cannery Lane and 30A resort suites priced for boutique retail."),
 ("Too small for six-plus operatories","116 Mc Davis Blvd, 250 Lynn Dr, 9375 Emerald Coast Pkwy, 3925 & 3754 & 2930 W CR-30A, 6925 US-98 #103, 12671 Emerald Coast Pkwy #217, 156 N CR-393, and the ground-floor micro-suites at 12598 US-98."),
 ("Off-budget, off-timeline, or too large","73 Veterans Rd ($28,000/mo), 5410 E CR-30A ($55/SF), 321 Serenoa Rd (industrial, 5,100+ SF), 679 Serenoa Rd (2029 delivery), 2050 W CR-30A #M1109 (highest CAM in the search)."),
]
ruledhtml="".join(f'<div class="rgroup"><h4>{t}</h4><p>{d}</p></div>' for t,d in ruled)

takeaways=[
 ("Ground floor is not negotiable.","Plumbing runs under the chairs, vacuum and compressor lines need a straight path, equipment has to be carried in, and patients leave unsteady after sedation. An elevator does not solve that. The ground-floor options above are the real candidates; the upstairs suites are noted only so nothing is hidden."),
 ("Purpose-built medical space barely exists on the coast.","Along the Santa Rosa Beach and Miramar corridor almost every option is a retail or office conversion, which is why confirming zoning is the first call. The one campus built for the use, Corporate Woods, sits inland in Freeport, and that is the core trade-off in this set: coastal proximity against a lower cost basis and better parking."),
 ("The North Bay options change the math on parking and price.","Freeport and Niceville deliver more square footage, lower rents, and stronger parking ratios than the 30A corridor, at the cost of drive time. How far patients will travel is the question that decides whether these belong at the top of the list."),
 ("Every rate shown is base rent only, unless marked gross.","Triple net quotes exclude taxes, insurance, and common area. Those figures are being confirmed with each landlord and are marked TBD until then, so base monthly rent is the working total on this page. A $22 NNN space and a $19 gross space can land closer than they look once operating expenses are counted."),
]
takehtml="".join(f'<div class="tk"><h4>{t}</h4><p>{d}</p></div>' for t,d in takeaways)

decide=[
 ("How many operatories?","The target range works out to roughly six to eight treatment rooms; a solo practice typically needs four or five. Building for a second doctor from day one, or growing into the space, changes which of these we push hardest on."),
 ("How far inland will you go for value?","The Freeport and Niceville options trade drive time for lower rent, more space, and better parking. If patients will follow, Corporate Woods and Palm Plaza move up; if the practice lives on 30A / Miramar foot traffic, they come off."),
 ("How you plan to bring patients in.","142 John Galt and Corporate Woods win on cost but sit off the retail street; the grocery-anchored and highway-frontage options win on visibility. Referral practice or drive-by practice weights the whole list."),
 ("Electrical service.","Three phase at 200 amps covers a dental office up to about 3,000 SF; above that you want 400. None of these publish panel capacity, so we verify building by building."),
 ("Parking and sedation.","A dental practice wants roughly five spaces per 1,000 SF; Corporate Woods and the grocery centers are strongest here. If sedation is planned, the building will likely need sprinklers and medical-gas rooms may need outside ventilation, both cheaper to solve before signing."),
]
decidehtml="".join(f'<div class="dq"><h4>{t}</h4><p>{d}</p></div>' for t,d in decide)

# ---------- assemble ----------
options = (std_card(p1)+std_card(p2)+std_card(p3)+std_card(p4)+std_card(p5)+std_card(p6)
           +center_card(grand)+center_card(corporate)+center_card(bluewater)+center_card(palm)
           +std_card(p7))

HTML = f'''<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pre-Tour Briefing · Dr. Elizabeth Hughes, DMD</title>
<style>{CSS}</style></head>
<body><div class="wrap">
<header>
  <div class="htop"><img src="{I['logo_white']}" alt="CARR"><span class="kick">Healthcare Real Estate</span></div>
  <h1>Pre-Tour Briefing<br>Dental Practice Space Search</h1>
  <div class="sub">Santa Rosa Beach · Miramar Beach · Freeport · Niceville · Destin · for lease</div>
  <div class="prep"><b>Prepared for Dr. Elizabeth Hughes, DMD</b> &nbsp;|&nbsp; Walton &amp; Okaloosa County, FL</div>
</header>
<main>
  <p class="lead">This is the full field of options to walk through before we tour, organized by submarket so an afternoon on the road follows a sensible route. The core Santa Rosa Beach and Miramar Beach corridor is here alongside a set of North Bay and Destin options, Freeport, Niceville, and Kelly Plantation, that trade drive time for lower rent, more space, and stronger parking. Every rate, floor, and open question is on the table so the tour confirms what we already know instead of discovering it.</p>
  <div class="snap">
    <div><div class="k">Practice</div><div class="v">Dental startup</div></div>
    <div><div class="k">Target size</div><div class="v">2,400–3,400 SF</div></div>
    <div><div class="k">Structure</div><div class="v">Lease</div></div>
    <div><div class="k">Submarkets</div><div class="v">5</div></div>
    <div><div class="k">Options presented</div><div class="v">11</div></div>
    <div><div class="k">Core area reviewed</div><div class="v">33</div></div>
    <div><div class="k">Purpose-built medical</div><div class="v">Corporate Woods</div></div>
    <div><div class="k">Base rent range</div><div class="v">$18–45 /SF</div></div>
  </div>
  <div class="fid">CARR represents healthcare tenants and buyers only. We never represent landlords or sellers, so there is no question about whose interests are being protected in your negotiation, and our services are at no cost to you.</div>

  <h2><span class="secnum">Where the core set is</span></h2>
  <div class="h2sub">Santa Rosa Beach through east Miramar Beach along the US-98 / 30A corridor. The Freeport, Niceville, and Destin options sit beyond this map to the north and east, roughly 15 to 30 minutes further inland.</div>
  <figure><img class="omap" src="{I['overview']}" alt="Map of the Santa Rosa Beach to Miramar Beach search area"><figcaption>Core search area, Miramar Beach and Sandestin (west) through Santa Rosa Beach (east). Map data © OpenStreetMap contributors.</figcaption></figure>
  <div class="routebox">
    <a class="routebtn" href="{TOURURL}" target="_blank" rel="noopener">Open the tour route in Google Maps →</a>
    <span class="routemeta">Crestview → Niceville → Freeport → Santa Rosa Beach → Miramar Beach → Destin · 8 stops · about 2 hr 18 min driving, one toll.</span>
  </div>

  <h2><span class="secnum">Options at a glance</span></h2>
  <div class="h2sub">Side by side across all five submarkets. Base rent is normalized where possible; multi-suite centers show a range and are detailed in their cards. All rates are base rent unless marked gross.</div>
  <div class="tblwrap"><table>
    <thead>{thead}</thead><tbody>{tbody}</tbody>
  </table></div>
  <p class="tnote">*Corporate Woods suites are 568–747 SF individually and combine to the target band. Base monthly rent is the working total; operating expenses are shown as TBD and confirmed with each landlord before any comparison. Full-buildout spaces carry a medical/office fit-out benchmark of roughly $180/SF, and a dental fit-out typically runs higher.</p>

  <h2><span class="secnum">The options</span> &nbsp;<span style="font-weight:400;color:#5b6675;font-size:14px">11 to tour</span></h2>
  <div class="h2sub">One numbered sequence across all five submarkets, each with my notes. The city and drive are on every card, and the map above shows how they sit relative to each other.</div>
  {options}

  <h2><span class="secnum">Also reviewed and set aside</span> &nbsp;<span style="font-weight:400;color:#5b6675;font-size:14px">24 in the core area</span></h2>
  <div class="h2sub">Listed so you see the whole field rather than a curated few. The reasons cluster into four groups.</div>
  <div class="rwrap">{ruledhtml}</div>

  <h2><span class="secnum">What this search tells you</span></h2>
  <div class="tkgrid">{takehtml}</div>

  <h2><span class="secnum">To decide together before we tour</span></h2>
  <div class="h2sub">The answers that reorder the list and shape the questions we take to each landlord.</div>
  <div class="dqgrid">{decidehtml}</div>
</main>
<footer>
  <div class="sig"><div>
      <div class="name">Dell McCraney</div>
      <div class="role">Healthcare Real Estate Advisor · CARR</div>
      <div class="contact"><a href="tel:+18508600749">850-860-0749</a><br><a href="mailto:dell.mccraney@carr.us">dell.mccraney@carr.us</a></div>
    </div>
    <img src="{I['logo_white']}" alt="CARR" style="height:26px;opacity:.95">
  </div>
  <div class="fidfoot">CARR is the nation's leading provider of healthcare commercial real estate services, representing tenants and buyers exclusively. We never represent landlords or sellers, and our services are at no cost to you, so the advice in your negotiation is protecting one side of the table: yours.</div>
  <div class="meta">Sources: CoStar · ECAR / Emerald Coast MLS · Moody's CRE · Crexi · Walton County tax roll · listing marketing packages. Figures are from listing data and public records and are confirmed with each landlord before any offer.</div>
</footer>
</div></body></html>'''

open('Hughes-PreTour-Briefing.html','w').write(HTML)
print("built:", len(HTML), "bytes")
